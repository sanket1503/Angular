const express = require('express')
const app = express()
const bodyparser = require('body-parser')
const mongoose = require('mongoose')
const url = 'mongodb://localhost/blogDb';
const User = require('./model/user');
const Tracks = require('./model/Tracks');
const Leads = require('./model/Lead');
var nodemailer = require("nodemailer");

var smtpTransport = nodemailer.createTransport({
    service: "gmail",
    host: "smtp.gmail.com",
    secure: false,
    auth: {
        user: "sanket1503@gmail.com",
        pass: ""
    }
});

app.use(bodyparser.json())
app.use(bodyparser.urlencoded({extended : false}))

app.get('/api/user/login',(req,res)=>{
    console.log('Inside app.js server side');
    mongoose.connect(url, function(err){
        console.log('Inside mongoose connect function');
        if(err) throw err;
        console.log('Connected Successfully, username is',req.body.username,'password is',req.body.password);
    })
    var mailOptions={
        to : "SanketGangaram.Gurav@cognizant.com",
        subject : "Test Email",
        text : "It's a Test Mail"
    }
     console.log("mailOptions"+mailOptions);
    smtpTransport.sendMail(mailOptions, function(error, response){
     if(error){
            console.log(error);
        //res.end("error");
     }else{
            console.log("Message sent: " + response.message);
        //res.end("sent");
         }
});

})

/*app.post('/api/user/login',(req,res)=>{
    console.log('Inside app.js server side');
    mongoose.connect(url, function(err){
        console.log('Inside mongoose connect function');
        if(err) throw err;
        console.log('Connected Successfully, username is',req.body.username,'password is',req.body.password);
    })
})*/

app.post('/api/user/getAllTracks',(req,res)=>{
    mongoose.connect(url,function(err){
        if(err) throw err;
       // console.log(User);
        Tracks.find({
            //username: req.body.username,
            //password: req.body.password
        }, function(err, Tracks){
            console.log('Tracks Details');
             console.log(Tracks.length);
            if(err) throw err;
            if(Tracks.length ===0){
                return res.status(200).json({
                     status: 'fail',
                    message: 'Failed'
                    
                })
            }else{
                return res.status(200).json({
                   status: 'success',
                    data: Tracks
                })
            }
        })
    });
})


app.post('/api/user/login',(req,res)=>{
var mailOptions={
        to : "SanketGangaram.Gurav@cognizant.com",
        subject : "Test Email",
        text : "It's a Test Mail"
    }
     console.log("mailOptions"+mailOptions);
    smtpTransport.sendMail(mailOptions, function(error, response){
     if(error){
            console.log(error);
        //res.end("error");
     }else{
            console.log("Message sent: " + response.message);
        //res.end("sent");
         }
});

    mongoose.connect(url,function(err){
        if(err) throw err;
        console.log(User);
        User.find({
            username: req.body.username,
            password: req.body.password
        }, function(err, user){
            console.log('User Details');
         
            if(err) throw err;
            if(user.length ===1){
                return res.status(200).json({
                    status: 'success',
                    data: user
                })
            }else{
                return res.status(200).json({
                    status: 'fail',
                    message: 'Login Failed'
                })
            }
        })
    });

    
})

app.post('/api/user/getTrackLeadDetails',(req,res)=>{
    mongoose.connect(url,function(err){
        if(err) throw err;
        console.log('req.body.lead_id'+req.body.lead_id);
        Leads.find({
            lead_id: req.body.lead_id
        }, function(err, Leads){
            console.log('User Details');
         
            if(err) throw err;
            if(Leads.length ===1){
                return res.status(200).json({
                    status: 'success',
                    data: Leads
                })
            }else{
                return res.status(200).json({
                    status: 'fail',
                    message: 'Login Failed'
                })
            }
        })
    });
})

app.listen(3001, ()=> console.log('PMO server running on port 3001'))