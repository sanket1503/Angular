const mongoose = require('mongoose');
const schema = mongoose.Schema;

const leadSchema = new schema({
    lead_id : {type: String, required: true, unique: true},
    lead_name: {type: String, required: true},
    lead_designation: {type: String}
},{collection:'Leads'});

const Leads = mongoose.model('Leads',leadSchema);

module.exports = Leads;