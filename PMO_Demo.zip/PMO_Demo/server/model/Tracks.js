const mongoose = require('mongoose');
const schema = mongoose.Schema;

const tracksSchema = new schema({
    track_id : {type: String, required: true, unique: true},
    track_name: {type: String, required: true},
    track_desc: {type: String},
    lead_id: {type: String}
},{collection:'Tracks'});

const Tracks = mongoose.model('Tracks',tracksSchema);

module.exports = Tracks;