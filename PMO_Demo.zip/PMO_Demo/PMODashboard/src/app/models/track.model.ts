export class Track{
    constructor(){
        this.lead_id = '';
    }
    public lead_id;
}