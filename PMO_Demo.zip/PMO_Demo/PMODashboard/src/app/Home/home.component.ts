import { Component, OnInit, Input } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { HomeService } from './home.service';
import { Track } from '../models/track.model';
 
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[ HomeService ]
})
export class HomeComponent implements OnInit{
  TrackList :any;
  @Input() lead_name : any;
  @Input() lead_design : any;
  @Input() selectDate : any;
  @Input() selectedDate : any;
  @Input() selectYear : any;
  @Input() selectQuarter : any;
  public track : Track;

  constructor(private homeService : HomeService,private router : Router){
    this.track = new Track();
  }
  populateTracks(){
    console.log("Inside ");
     this.homeService.populateTracks().subscribe(result => {
        console.log('result is ', result['data']);
        this.TrackList = result['data'];
        if(result['status'] === 'success') {  
          //this.router.navigate(['/home']);
         //alert('Success');
        } else {
          alert('Fail');
        }
      }, error => {
        console.log('error is ', error);
      });
  }

  getTrackLeadDetails(){
     this.homeService.getTrackLeadDetails(this.track).subscribe(result => {
        console.log('result is ', result['data'][0].lead_name);
        console.log('this.user.username ', this.track);
        this.lead_name = result['data'][0].lead_name;
        this.lead_design = result['data'][0].lead_designation;
        if(result['status'] === 'success') {  
          
        } else {
          alert('Fail');
        }
      }, error => {
        console.log('error is ', error);
      });
  }

  getDetailDate(value){
    var selectedDate = new Date(this.selectDate);
    var selectedYear = selectedDate.getFullYear();
    var selectedMonth = selectedDate.getMonth()+1;
    var quarter = Math.floor((selectedMonth + 2) / 3);
    this.selectedDate = selectedDate;
    this.selectYear = selectedYear;
    this.selectQuarter = 'Q'+quarter;
  }

  ngOnInit(){
    this.populateTracks();
  }
  
}