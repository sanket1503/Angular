import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Track } from '../models/track.model';

@Injectable()
export class HomeService{
    constructor(private http: HttpClient){

    }

    populateTracks(){
       
        return this.http.post('/api/user/getAllTracks',{
            //username : user.username,
            //password : user.password
        })
    }

    getTrackLeadDetails(track : Track){
         return this.http.post('/api/user/getTrackLeadDetails',{
            lead_id : track.lead_id
        })
    }
}