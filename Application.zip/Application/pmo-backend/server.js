const file = require('./upload.js');
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const server = express();
const corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200,
};

server.use(cors(corsOptions))
server.use(bodyParser.urlencoded({extended: true}))
server.use(bodyParser.json())

server.post('/upload', file.upload.single('excel'),function (req, res) {
    if (!req.file) {
        console.log("No file received");
        return res.send({
          success: false
        });
    
      } else {
        console.log('file received');
        return res.send({
          success: true
        })
      }
});

server.listen(8000, () => {
  console.log('Server started!')
})