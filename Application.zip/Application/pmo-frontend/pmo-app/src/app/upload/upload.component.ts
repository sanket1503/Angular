import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
// import { UploadService } from './upload.service';
import {  FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';

const URL = 'http://localhost:8000/upload';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

 @ViewChild('myInput', {static: true})
 myInputVariable: ElementRef;

 public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'excel'});
 
   ngOnInit() {
      
      this.uploader.onAfterAddingFile = (file) => {
        var ext = file.file.name.split(".")[1];
        console.log(ext)
        console.log(ext === "xlsx");
        
        if(ext !== "xls"){
          if(ext !== "xlsx"){
            alert("Extension not supported");
            this.uploader.queue.length = 0;
          }
        }
        let len = this.uploader.queue.length;
        
        if(len > 1){
          for(var i=0;i<len-1;i++){
            this.uploader.queue[i].remove();
          }
        }
        
        file.withCredentials = false; 
      };
      
      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        console.log('ImageUpload:uploaded:', item, status, response);
        alert('File uploaded successfully');
      };
  }

  reset() {
      this.myInputVariable.nativeElement.value = "";
      this.uploader.queue.length=0;
  }

}
