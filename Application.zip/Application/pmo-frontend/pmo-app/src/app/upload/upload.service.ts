import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http: HttpClient) { }

  upload(file: File){
    this.http.post('http://localhost:8000/upload', file)
            .subscribe((response) => {
                console.log('response received is ', response);
            });
  }
}
