import { Component, OnInit } from '@angular/core';
import { Item } from '../models/item'; 
import { ItemService} from '../services/item.service';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {

  items: Item[];
  constructor(private its: ItemService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData(){
    this.items=this.its.getAllItems();
  }

  itemSaveHandler(item:Item){
    this.its.updateItem(item);
    this.loadData();
  }

  itemSaveCancelHandler(item:Item){
      this.loadData();
  }

  deleteHandler(item:Item){
    this.its.deleteItem(item.ItemId);
    this.loadData();
  }

}
