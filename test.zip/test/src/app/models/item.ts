export class Item {
    public ItemId: number;
    public ItemName: String;
    public ItemCost: number;
    public packageDate: String;
    
}
