import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Item } from '../models/item';


@Component({
  selector: 'app-item-list-row',
  templateUrl: './item-list-row.component.html',
  styleUrls: ['./item-list-row.component.css']
})
export class ItemListRowComponent implements OnInit {

  @Input() item: Item;

  @Output() onItemSaved:EventEmitter<Item>;
  @Output() onItemSaveCanceled:EventEmitter<Item>;
  @Output() onItemDeleted:EventEmitter<Item>;


  isEditing: boolean;
  constructor() { 
    this.isEditing=false;
    this.onItemDeleted= new EventEmitter<Item>();
    this.onItemSaved= new EventEmitter<Item>();
    this.onItemSaveCanceled= new EventEmitter<Item>();
  }

  ngOnInit() {
  }
  
  editClickHandler(){
    this.isEditing= true;
  
  }

  saveClickHandler(){
    this.isEditing=false;  
    this.onItemSaved.emit(this.item);

  }

  cancelClickHandler(){
    this.isEditing=false;  
    this.onItemSaveCanceled.emit(this.item);
    
  }
  
  deleteClickHandler(){
    if(confirm(`Are you sure you want to Delete Item#${this.item.ItemId}?`)){
      this.onItemDeleted.emit(this.item);
    }
    ;  
    
    
  }




}
