import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  webAppTitle : string;
  webTagLine : String;
    itemCount:number;

  constructor(private itemServiceObj:ItemService) { 
    this.webAppTitle = environment.AppTitle;
  this.webTagLine = environment.tagLine;

  }

  ngOnInit() {
    this.itemCount=this.itemServiceObj.getAllItems().length;
  }

}
