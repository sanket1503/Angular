import { Injectable } from '@angular/core';
import { Item} from '../models/item';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  items: Item[];
  constructor() { 
    this.items = [{ItemId:101,ItemName:'Ruled Notes 1',ItemCost:120,packageDate:(new Date()).toISOString()},
    {ItemId:102,ItemName:'Ruled Notes 2',ItemCost:20,packageDate:(new Date()).toISOString()},
    {ItemId:103,ItemName:'Ruled Notes 3',ItemCost:220,packageDate:(new Date()).toISOString()},
    {ItemId:104,ItemName:'Ruled Notes 4',ItemCost:12,packageDate:(new Date()).toISOString()},
    {ItemId:105,ItemName:'Ruled Notes 5',ItemCost:10,packageDate:(new Date()).toISOString()}];
    
  }

  getAllItems():Item[]{
      return this.items;
  }

  getItemById(id: number):Item{
    let item:Item = null;
    item = this.items.find( i => i.ItemId == id) ;
    return item;
  } 

  updateItem(item:Item){
    let index = this.items.findIndex(i=>i.ItemId==item.ItemId);
    if(index>-1){
        this.items[index]=item;
    }
  }

  deleteItem(id:number){
    let index = this.items.findIndex(i=>i.ItemId==id);
    if(index>-1){
        this.items.splice(index,1);
    }
  }
}
