export const environment = {
  production: true,
  AppTitle:"SKML Traders",
  tagLine:"..a simple SPA CRUD App.."
};