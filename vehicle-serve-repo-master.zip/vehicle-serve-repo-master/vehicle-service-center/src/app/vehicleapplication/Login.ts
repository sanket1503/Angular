export class Login {
    userId:string;
    password:string;
    constructor(values: Object = {}) {
      Object.assign(this, values);
    }
}