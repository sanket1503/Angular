import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {Login} from '../vehicleapplication/Login';
import { VehicleApplicationService } from '../vehicleapplication/vehicle-application.service';
import { FormGroup, Validators,FormControl } from '@angular/forms';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

 newApplication: Login;
  loginForm: FormGroup;

  constructor(private vehicleApplicationService: VehicleApplicationService,private router: Router) { 

    this.loginForm=new FormGroup(
      {
         
         userId: new FormControl(),
         password: new FormControl()

      }
    
    ); }

  ngOnInit() {
  }

  validateUser(){
     this.newApplication = this.loginForm.value;
    console.log('firstName...:'+this.newApplication);
    //this.vehicleApplicationService.addUser(this.newApplication);
    //this.vehicleApplicationService.
    this.router.navigate(['/user-login']);
     
    
  
  }
}
