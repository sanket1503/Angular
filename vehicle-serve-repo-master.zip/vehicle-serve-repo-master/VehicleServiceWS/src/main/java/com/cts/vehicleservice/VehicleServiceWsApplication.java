package com.cts.vehicleservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleServiceWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleServiceWsApplication.class, args);
	}

}
